package com.application.sharedlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationSharedLibApplicationTests {

	@Test
	void contextLoads() {
	}

}
