Bank application built using spring Boot Java
