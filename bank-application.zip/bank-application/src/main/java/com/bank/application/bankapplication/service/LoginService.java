package com.bank.application.bankapplication.service;

public interface LoginService {

	void loginCustomer(String userName, String password) throws Exception;

}
