package com.bank.application.bankapplication.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.bank.application.bankapplication.entity.Accounts;
import com.bank.application.bankapplication.entity.TransactionType;
import com.bank.application.bankapplication.entity.Transactions;
import com.bank.application.bankapplication.repository.BankAccountRepository;
import com.bank.application.bankapplication.repository.CustomerRepository;
import com.bank.application.bankapplication.repository.TransactionRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@Service
@Transactional
@Profile(value = { "local", "dev", "prod" })
public class BankAccountServiceImpl implements BankAccountService {

	@Autowired
	BankAccountRepository bankAccountRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	TransactionRepository transactionRepository;

	public void createBankAccount(Accounts account) throws Exception {
		int accountNumber = account.getAccountNumber();
		Optional<Accounts> accountresposne = bankAccountRepository.findById(accountNumber);
		if (accountresposne.isPresent()) {
			throw new Exception(BanksConstants.ACCOUNT_DETAILS_EXISTS);
		}

		account.setAccountStatus(BanksConstants.ACTIVE);
		Accounts accountDetails = bankAccountRepository.save(account);
		if (accountDetails == null) {
			throw new Exception(BanksConstants.DETAILS_NOT_SAVED);
		}
	}

	public List<Accounts> getAllAccounts(int cifNumber) throws Exception {
		List<Accounts> accountDetails = bankAccountRepository.findAccountsByCifNumber(cifNumber).stream()
				.filter(details -> details.getAccountStatus().equals(BanksConstants.ACTIVE)).map(data -> {
					data.getCustomer().setCifNumber(cifNumber);
					return data;
				}).collect(Collectors.toList());

		if (accountDetails.isEmpty()) {
			throw new Exception(BanksConstants.DETAILS_NOT_FOUND);
		}
		System.out.println(accountDetails);
		return accountDetails;
	}

	@Override
	public Float getBalance(int accountNumber) throws Exception {

		Optional<Accounts> accountDetailsResponse = bankAccountRepository.findById(accountNumber);

		if (!accountDetailsResponse.isPresent()) {
			throw new Exception(BanksConstants.DETAILS_NOT_FOUND);
		}

		Float bankBalance = accountDetailsResponse.get().getAmount();

		return bankBalance;

	}

	@Override
	public String accountDelete(int accountNumber) throws Exception {
		bankAccountRepository.deleteById(accountNumber);
		return BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY;
	}

	@Override
	public String removeAccount(int accountNumber) throws Exception {
		float finalAmount = 0;
		Optional<Accounts> accountResponse = bankAccountRepository.findById(accountNumber);
		if (!accountResponse.isPresent()) {
			throw new Exception(BanksConstants.DETAILS_NOT_FOUND);
		}

		float accountBalance = accountResponse.get().getAmount();
		Transactions transactionsResponse = updateTransaction(accountBalance, accountNumber, finalAmount);
		transactionRepository.save(transactionsResponse);
		bankAccountRepository.updateAccountStatusToInactive(BanksConstants.INACTIVE, accountNumber, finalAmount);
		return BanksConstants.BANK_ACCOUNT_REMOVED_SUCCESSFULLY;
	}

	private Transactions updateTransaction(float accountBalance, int accountNumber, float finalAmount) {
		Transactions transactionDetails = new Transactions();
		transactionDetails.setAmount(accountBalance);
		transactionDetails.setAccountNumber(accountNumber);
		transactionDetails.setDescription(BanksConstants.AMOUNT_WITHDRAWN);
		transactionDetails.setTransactionType(TransactionType.DEBITED);
		transactionDetails.setTotalAmount(finalAmount);
		return transactionDetails;
	}

}