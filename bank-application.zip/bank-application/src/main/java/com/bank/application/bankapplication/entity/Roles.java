package com.bank.application.bankapplication.entity;

public enum Roles {

    MANAGER("MANAGER"), USER("USER"), EMPLOYEE("EMPLOYEE");

    private String code;

    Roles(String code) {
        this.code = code;
    }

    public String code() {
        return this.code;
    }

}