package com.bank.application.bankapplication.service;

import com.bank.application.bankapplication.entity.Employee;

public interface BankEmployeeService {

	void createBankEmployee(Employee employee) throws Exception;

	void createManager(Employee employee) throws Exception;

}
