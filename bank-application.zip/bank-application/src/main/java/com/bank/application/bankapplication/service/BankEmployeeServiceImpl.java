package com.bank.application.bankapplication.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.application.bankapplication.entity.Employee;
import com.bank.application.bankapplication.entity.Roles;
import com.bank.application.bankapplication.repository.BankEmployeeRepository;
import com.bank.application.bankapplication.util.BanksConstants;

@Service
@Transactional
public class BankEmployeeServiceImpl implements BankEmployeeService {

	@Autowired
	BankEmployeeRepository repository;

	@Override
	public void createBankEmployee(Employee employee) throws Exception {
		employee.setEmployeeStatus(BanksConstants.ACTIVE);
		employee.getUser().setRole(Roles.EMPLOYEE);
		Employee employeeResponse = repository.save(employee);
		if (employeeResponse == null) {
			throw new Exception("Details doesnt saved");
		}
	}

	@Override
	public void createManager(Employee employee) throws Exception {
		employee.setEmployeeStatus(BanksConstants.ACTIVE);
		employee.getUser().setRole(Roles.MANAGER);
		Employee employeeResponse = repository.save(employee);
		if (employeeResponse == null) {
			throw new Exception("Details doesnt saved");
		}
	}

}
