package com.bank.application.bankapplication.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.sun.istack.NotNull;

import lombok.Data;
import lombok.ToString;

@Entity
@Data
public class Employee implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "seq", initialValue = 333)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private Integer EmployeeId;
	private String fullName;
	private String employeeName;
	private String mobileNumber;
	private String address;
	private String employeeStatus;

	@Enumerated(EnumType.STRING)
	@NotNull
	@Column(name = "gender")
	private Gender gender;

	@ToString.Exclude
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
	private User user;

}
