package com.bank.application.bankapplication.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import com.sun.istack.NotNull;

import lombok.Data;

@Entity
@Data
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name = "seq", initialValue = 1111)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private Integer id;

	@Column(unique = true, nullable = false)
	private String userName;
	@NotNull
	private String password;
	@Enumerated(EnumType.STRING)
	@NotNull
	private Roles role;

}
